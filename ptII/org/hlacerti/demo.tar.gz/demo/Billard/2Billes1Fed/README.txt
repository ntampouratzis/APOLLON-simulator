These files are test models for the improved HLA/Certi cosimulation framework.

TwoBilliardBalls.xml is a federate with 2 billiard balls modelised
as two instances of the class Bille.

PoolTable2.xml is a federate which receives and displays the results.
(see Test.fed file for the FOM description).

Open the file 2Billes1Fed.xml and follow the instructions.

For more information, see README in folder "billard".

File makefile does not work on July, 28, 2017.
