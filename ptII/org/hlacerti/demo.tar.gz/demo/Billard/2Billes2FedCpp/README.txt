These files are test models for the improved HLA/Certi cosimulation framework.

This scenario is similar to the one in folder "2Billes1Fed" but each "bille"
(ball) is a federate (in a different Ptolemly model): Bille.xml and Bille2.xml.
They can interact with a "bille" from a C++ federate (certi demo).

Open the file 2Billes2FedCpp.xml and follow the instructions.
For more information, see README in folder "billard".
