These files are test models for the improved HLA/Certi cosimulation framework.

This scenario is similar to the one in folder "2Billes1Fed" but each "bille"
(ball) is a federate (in a different Ptolemly model): Bille.xml and Bille2.xml.

Open the file 2Billes2Fed.xml and follow the instructions.
For more information, see README in folder "billard".
