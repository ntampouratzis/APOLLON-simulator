Janette Cardoso, july 2017

This is a Federation with 2 federates: 
- testTimeAdvancingF2.xml: set parameter synchronizeToRealTime in DE director for forcing the time to advance in a federate 
- testTimeAdvancingF1.xml
No federate sends any UAV. 

First of all set Ptolemy and CERTI environment variables as explained in the 
manual in $PTII/org/hlacerti/manual-ptii-hla.pdf.

Open the file Federation2federatesAdvancingTime.xml with the links to above models and
some explanation.
