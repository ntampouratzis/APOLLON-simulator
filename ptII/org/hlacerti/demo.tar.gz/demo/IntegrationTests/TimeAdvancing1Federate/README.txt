Janette Cardoso, july 2017

This is a Federation with a unique federate: TimeAdvancing1Federate.xml.

Open the model TimeAdvancing1Federate.xml
after set Ptolemy and CERTI environment variables as explained in the 
manual in $PTII/org/hlacerti/manual-ptii-hla.pdf.
