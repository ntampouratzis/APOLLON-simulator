Janette Cardoso, july 2017

This is a Federation with a 2 federates: 
- testTimeAdvancingF2.xml: generates internal events
- testTimeAdvancingF1.xml: 
No federate sends any UAV. 

First of all set Ptolemy and CERTI environment variables as explained in the 
manual in $PTII/org/hlacerti/manual-ptii-hla.pdf.

Open the file Federation2federatesAdvancingTime.xml with the links to above models and
some explanation.
